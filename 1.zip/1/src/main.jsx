import React from "react";
import ReactDOM from "react-dom/client";
import { Layout } from "./front/layout";
import { HomeView } from "./front/views/home";
import { NewsDetailView, NewsView } from "./front/views/news";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./front/redux/config/store";
import "./index.css";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        path: "",
        element: <HomeView />,
      },
      {
        path: "news",
        element: <NewsView />,
      },
      {
        path: "newsdetail",
        element: <NewsDetailView />,
      },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <RouterProvider router={router} />
  </Provider>
);
