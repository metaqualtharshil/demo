import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { showNews } from "../redux/actions";
import moment from "moment/moment";
import { NavLink } from "react-router-dom";

const News = () => {
  const dispatch = useDispatch();
  const { news, isLoading } = useSelector((state) => state.news);
  useEffect(() => {
    dispatch(showNews());
  }, []);
  if (isLoading) {
    return <h2>Loading.....</h2>;
  }
  return (
    <>
      <div className="container mt-5">
        <div className="row">
          <div className="col-lg-8 ">
            {news &&
              news.map((item) => (
                <NavLink to={"/newsdetail"}>
                  <div className="card mb-3" id={item.uuid}>
                    <div className="row">
                      <div className="col-md-3">
                        <img
                          src={item.image_url}
                          alt="..."
                          className="img-fluid rounded w-100 d-block"
                          style={{ height: "160px" }}
                        />
                      </div>
                      <div className="col-md-9">
                        <div className="card-body p-1">
                          <h5 className="card-title">{item.title}</h5>
                          <p className="card-text description">
                            {item.description}
                          </p>
                          <p className="card-text">
                            <small className="text-muted">
                              <span>
                                {moment(item.published_at).format(
                                  "MMMM DD, YYYY"
                                )}
                              </span>
                            </small>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </NavLink>
              ))}
          </div>
          <div className="col-lg-4">
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <nav aria-label="Page navigation example">
            <ul className="pagination justify-content-end">
              <li className="page-item disabled">
                <a className="page-link">Previous</a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  1
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  2
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  3
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  Next
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </>
  );
};

export default News;
