import React from "react";

const NewsDetail = () => {
  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-lg-8 posts-list">
            <div className="single-post">
              <div className="feature-img ">
                <img
                  className="img-fluid"
                  style={{ width: "850px", height: "450px" }}
                  src="/frontend/images/post-item1.jpg"
                  alt=""
                />
              </div>
              <div className="blog_details mt-2">
                <h2>
                  Second divided from form fish beast made every of seas all
                  gathered us saying he our
                </h2>
                <ul className="blog-info-link mt-3 mb-4">
                  <li>
                    <a href="#">
                      <i className="fa fa-user" /> Travel, Lifestyle
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i className="fa fa-comments" /> 03 Comments
                    </a>
                  </li>
                </ul>
                <p className="excert">
                  MCSE boot camps have its supporters and its detractors. Some
                  people do not understand why you should have to spend money on
                  boot camp when you can get the MCSE study materials yourself
                  at a fraction of the camp price. However, who has the
                  willpower
                </p>
                <p>
                  MCSE boot camps have its supporters and its detractors. Some
                  people do not understand why you should have to spend money on
                  boot camp when you can get the MCSE study materials yourself
                  at a fraction of the camp price. However, who has the
                  willpower to actually sit through a self-imposed MCSE
                  training. who has the willpower to actually
                </p>
                <div className="quote-wrapper">
                  <div className="quotes">
                    MCSE boot camps have its supporters and its detractors. Some
                    people do not understand why you should have to spend money
                    on boot camp when you can get the MCSE study materials
                    yourself at a fraction of the camp price. However, who has
                    the willpower to actually sit through a self-imposed MCSE
                    training.
                  </div>
                </div>
                <p>
                  MCSE boot camps have its supporters and its detractors. Some
                  people do not understand why you should have to spend money on
                  boot camp when you can get the MCSE study materials yourself
                  at a fraction of the camp price. However, who has the
                  willpower
                </p>
                <p>
                  MCSE boot camps have its supporters and its detractors. Some
                  people do not understand why you should have to spend money on
                  boot camp when you can get the MCSE study materials yourself
                  at a fraction of the camp price. However, who has the
                  willpower to actually sit through a self-imposed MCSE
                  training. who has the willpower to actually
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-4">
            <h5>Top News</h5>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="services-item bg-light border-4 border-start border-primary rounded p-1 mb-3">
              <div className="row align-items-center">
                <div className="col-lg-3">
                  <div className="services-img d-flex align-items-center justify-content-center rounded">
                    <img
                      src="/frontend/images/commentor-item1.jpg"
                      className="img-fluid rounded"
                      alt=""
                      style={{
                        width: "60px",
                        height: "60px",
                      }}
                    />
                  </div>
                </div>
                <div className="col-lg-9">
                  <div className="services-content text-start">
                    <h6>Stone Therapy</h6>
                    <p>Lorem Ipsum is simply dummy</p>
                    <p>Last updated 3 mins ago</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default NewsDetail;
