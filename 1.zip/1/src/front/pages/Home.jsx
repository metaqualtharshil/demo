import React from "react";

const Home = () => {
  return <div>gfjjgkjh</div>;
};

export default Home;
