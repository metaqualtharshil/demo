import News from "./News";
import Home from "./Home";
import NewsDetail from "./NewsDetail";
export { News, Home, NewsDetail };
