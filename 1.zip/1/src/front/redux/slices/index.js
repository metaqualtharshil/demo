import newsSlice from "./news.slice";
export { newsSlice };
