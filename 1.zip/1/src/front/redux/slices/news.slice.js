import { createSlice } from "@reduxjs/toolkit";
import { showNews } from "../actions";

export const newsSlice = createSlice({
  name: "newsSlice",
  initialState: {
    news: [],
    isLoading: false,
    errorMessage: null,
  },
  extraReducers: (builder) => {
    builder.addCase(showNews.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(showNews.fulfilled, (state, action) => {
      state.isLoading = false;
      state.news = action.payload;
    });
    builder.addCase(showNews.rejected, (state, action) => {
      state.isLoading = false;
      state.errorMessage = action.error.message;
    });
  },
});

export default newsSlice.reducer;
