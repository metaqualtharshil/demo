import { showNews } from "./news.action";
export { showNews };
