import React from "react";
import { NewsDetail } from "../../pages";

const NewsDetailView = () => {
  return (
    <>
      <NewsDetail />
    </>
  );
};

export default NewsDetailView;
