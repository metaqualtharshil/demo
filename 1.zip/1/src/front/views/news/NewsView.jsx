import React from "react";
import { News } from "../../pages";
import { Carousel } from "../../components";

const NewsView = () => {
  return (
    <>
      <Carousel />
      <News />
    </>
  );
};

export default NewsView;
