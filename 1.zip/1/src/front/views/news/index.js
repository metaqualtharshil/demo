import NewsView from "./NewsView";
import NewsDetailView from "./NewsDetailView";
export { NewsView, NewsDetailView };
