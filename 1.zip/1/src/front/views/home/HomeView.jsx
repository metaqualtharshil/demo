import React from "react";
import { Home } from "../../pages";

const HomeView = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default HomeView;
